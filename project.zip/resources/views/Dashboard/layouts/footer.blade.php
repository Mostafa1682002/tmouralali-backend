<!-- Footer opened -->
<footer class="bg-white p-4">
    <div class="row">
        <div class="col-md-12">
            <div class="text-center">
                <p class="mb-0">
                    جميع الحقوق محفوظه &copy; {{ date('Y') }} <a href="">متجر تمور العلي</a>
                </p>
            </div>
        </div>
    </div>
</footer>
<!-- Footer closed -->
