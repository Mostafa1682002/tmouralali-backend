<?php $__env->startSection('title'); ?>
    فاتورة طلب
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        @media print {
            #print_Button {
                display: none;
            }
        }
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
    <div class="page-title">
        <div class="row">
            <div class="col-sm-6">
                <h4 class="mb-0">فاتورة طلب</h4>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right ">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="default-color">الرئيسيه</a></li>
                    <li class="breadcrumb-item active">فاتورة طلب</li>
                </ol>
            </div>
        </div>
    </div>
    <!-- breadcrumb -->
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-xl-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body" id="print">
                    
                    <div class="row mg-t-20">
                        <div class="col-md">
                            <h4 class="invoice-info-row"><span>اسم العميل</span> :
                                <span><?php echo e($order->user->name); ?></span>
                            </h4>
                            <p class="h-5">عنوان العميل : <?php echo e($order->address); ?></p>
                        </div>
                    </div>
                    <div class="table-responsive mg-t-40">
                        <table class="table table-invoice border text-md-nowrap mb-0">
                            <thead>
                                <tr>
                                    <th class="text-center">#</th>
                                    <th class="text-left">اسم المنتج</th>
                                    <th class="text-center">الصوره</th>
                                    <th class="text-center">الكميه</th>
                                    <th class="text-center">السعر</th>

                                    <th class="text-center">الاجمالي</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td class="text-center"><?php echo e($loop->index + 1); ?></td>
                                        <td class="text-left"><?php echo e($product->name); ?></td>
                                        <td class="text-center"><img src="<?php echo e($product->main_image); ?>"
                                                style="width:50px;height:50px" alt=""></td>
                                        <td class="text-center"><?php echo e($product->pivot->qty); ?></td>
                                        <td class="text-center"><?php echo e($product->pivot->price); ?> ريال</td>

                                        <td class="text-center"><?php echo e($product->pivot->qty * $product->pivot->price); ?>

                                            ريال</td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="valign-middle" colspan="4">
                                        <div class="invoice-notes">
                                            <label class="main-content-label text-13"></label>
                                        </div><!-- invoice-notes -->
                                    </td>
                                    <td class="text-right">رسوم التوصيل</td>
                                    <td class="text-center" colspan="3">28 ريال.</td>
                                </tr>
                                <tr>
                                    <td class="valign-middle" colspan="4">
                                        <div class="invoice-notes">
                                            <label class="main-content-label text-13"></label>
                                        </div><!-- invoice-notes -->
                                    </td>
                                    <td class="text-right">الاجمالي</td>
                                    <td class="text-center" colspan="2"><?php echo e($order->total); ?> ريال</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <hr class="mg-b-40">
                    <button class="btn btn-danger  float-left mt-3 mr-2" id="print_Button" onclick="printDiv()"> <i
                            class="mdi mdi-printer ml-1"></i>طباعة</button>
                </div>
            </div>

        </div>
    </div>

    <!-- row closed -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <!--Internal  Chart.bundle js -->
    <script type="text/javascript">
        function printDiv() {
            var printContents = document.getElementById('print').innerHTML;
            var originalContents = document.body.innerHTML;
            document.body.innerHTML = printContents;
            window.print();
            document.body.innerHTML = originalContents;
            location.reload();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u572991200/domains/tmouralali.shop/public_html/resources/views/Dashboard/showOrder.blade.php ENDPATH**/ ?>