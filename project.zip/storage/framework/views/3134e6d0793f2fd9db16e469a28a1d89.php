<div class="container-fluid">
    <div class="row">
        <!-- Left Sidebar start-->
        <div class="side-menu-fixed">
            <div class="scrollbar side-menu-bg">
                <ul class="nav navbar-nav side-menu" id="sidebarnav">
                    <!-- menu item Home-->
                    <li>
                        <a href="<?php echo e(route('admin.home')); ?>"><i class="ti-home"></i><span class="right-nav-text">الرئيسيه
                            </span></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('admin.products.index')); ?>"><i class="fa-solid fa-city"></i><span
                                class="right-nav-text"> قائمة المنتجات
                            </span> </a>
                    </li>
                    <!-- menu item Contacts-->
                    <li>
                        <a href="<?php echo e(route('admin.contacts.index')); ?>"><i class="fas fa-comments"></i><span
                                class="right-nav-text"> قائمة الرسائل</span></a>
                    </li>
                    <!-- menu item Orders-->
                    <li>
                        <a href="<?php echo e(route('admin.orders.index')); ?>"><i class="fa-solid fa-basket-shopping"></i><span
                                class="right-nav-text"> قائمة الطلبات</span></a>
                    </li>
                    <!-- menu item Users-->
                    <li>
                        <a href="<?php echo e(route('admin.users.index')); ?>"><i class="fas fa-users"></i><span
                                class="right-nav-text">
                                قائمة المستخدمين</span></a>
                    </li>
                    <!-- menu item Settings-->
                    
                </ul>
            </div>
        </div>

        <!-- Left Sidebar End-->

        <!--=================================
<?php /**PATH /home/u572991200/domains/tmouralali.shop/public_html/resources/views/Dashboard/layouts/main-sidebar.blade.php ENDPATH**/ ?>