<?php $__env->startSection('title'); ?>
    قائمة الطلبات
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    <!-- breadcrumb -->
    <div class="page-title">
        <div class="row">
            <div class="col-sm-6">
                <h4 class="mb-0">قائمة الطلبات</h4>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb pt-0 pr-0 float-left float-sm-right ">
                    <li class="breadcrumb-item"><a href="<?php echo e(route('admin.home')); ?>" class="default-color">الرئيسيه</a></li>
                    <li class="breadcrumb-item active">قائمة الطلبات</li>
                </ol>
            </div>
        </div>
    </div>
    <!-- breadcrumb -->
<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>
    <!-- row -->
    <div class="row">
        <div class="col-xl-12 mb-30">
            <div class="card card-statistics h-100">
                <div class="card-body">
                    <br><br>
                    <div class="table-responsive">
                        <table id="datatable" class="table  table-hover table-sm table-bordered p-0" data-page-length="50"
                            style="text-align: center">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>رقم الطلب</th>
                                    <th>العميل</th>
                                    <th>الهاتف</th>
                                    <th>الاجمالي</th>
                                    <th>العمليات</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($loop->index + 1); ?></td>
                                        <td><?php echo e($order->id); ?></td>
                                        <td><?php echo e($order->user->name); ?></td>
                                        <td><?php echo e($order->phone); ?></td>
                                        <td><?php echo e($order->total); ?></td>
                                        <td>

                                            <a href="<?php echo e(route('admin.orders.show', $order->id)); ?>"
                                                class="btn btn-warning btn-sm text-white" title="عرض"><i
                                                    class="fas fa-eye"></i></a>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- row closed -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Dashboard.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u572991200/domains/tmouralali.shop/public_html/resources/views/Dashboard/order.blade.php ENDPATH**/ ?>