<!-- Footer opened -->
<footer class="bg-white p-4">
    <div class="row">
        <div class="col-md-12">
            <div class="text-center">
                <p class="mb-0">
                    جميع الحقوق محفوظه &copy; <?php echo e(date('Y')); ?> <a href="">متجر تمور العلي</a>
                </p>
            </div>
        </div>
    </div>
</footer>
<!-- Footer closed -->
<?php /**PATH /home/u572991200/domains/tmouralali.shop/public_html/resources/views/Dashboard/layouts/footer.blade.php ENDPATH**/ ?>