<?php $__env->startSection('content'); ?>
    <!-- Start Breadcrumbs -->
    <div class="breadcrumbs">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="breadcrumbs-content">
                        <h1 class="page-title">تسجيل الدخول</h1>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <ul class="breadcrumb-nav">
                        <li>
                            <a href="<?php echo e(route('home')); ?>"><i class="lni lni-home"></i> الرئيسيه</a>
                        </li>
                        <li>تسجيل الدخول</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumbs -->

    <!-- Start Account Login Area -->
    <div class="account-login section">
        <div class="container">
            <div class="row">
                <!-- class="col-lg-6 offset-lg-3 col-md-10 offset-md-1 col-12" -->
                <!-- style="margin-right: 25%" -->
                <div>
                    <form class="card login-form" method="post" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="card-body">
                            <div class="title">
                                <h3>تسجيل الدخول</h3>
                            </div>
                            <div class="form-group input-group">
                                <label for="reg-fn">البريد الالكتروني</label>
                                <input class="form-control" name="email" type="email" id="reg-email" required />
                            </div>
                            <div class="form-group input-group">
                                <label for="reg-fn">الرقم السري</label>
                                <input class="form-control" name="password" type="password" id="reg-pass" required />
                            </div>
                            <div class="d-flex flex-wrap justify-content-between bottom-content">
                                <a class="lost-pass" href="account-password-recovery.html">هل نسيت الرقم السري ؟</a>
                                <div class="form-check" style="padding-left: 0">
                                    <label class="form-check-label">تذكرني</label>
                                    <input type="checkbox" value="1" value="remember"
                                        class="form-check-input width-auto" id="exampleCheck1"
                                        style="float: right; margin-right: -1.5em" />
                                </div>
                            </div>
                            <div class="button">
                                <button class="btn" type="submit">دخول</button>
                            </div>
                            <p class="outer-link">
                                ليس لديك حساب؟
                                <a href="<?php echo e(route('register')); ?>"> سجل هنا </a>
                            </p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- End Account Login Area -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u572991200/domains/tmouralali.shop/public_html/resources/views/auth/login.blade.php ENDPATH**/ ?>