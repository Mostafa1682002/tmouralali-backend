<?php $__env->startSection('content'); ?>
    <!-- Start Breadcrumbs -->
    <div class="breadcrumbs">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="breadcrumbs-content">
                        <h1 class="page-title">السلة</h1>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <ul class="breadcrumb-nav">
                        <li>
                            <a href="<?php echo e(route('home')); ?>"><i class="lni lni-home"></i> الرئيسيه</a>
                        </li>
                        <li><a href="<?php echo e(route('products')); ?>">المنتجات</a></li>
                        <li>السلة</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumbs -->
    <?php if(Cart::instance('cart')->count() == 0): ?>
        <div class="shopping-cart section" style="    text-align: center;
    font-size: 30px;">السلة فارغة</div>
    <?php else: ?>
        <!-- Shopping Cart -->
        <div class="shopping-cart section">
            <div class="container">
                <div class="cart-list-head">
                    <!-- Cart List Title -->
                    <div class="cart-list-title">
                        <div class="row">
                            <div class="col-lg-1 col-md-1 col-12"></div>
                            <div class="col-lg-4 col-md-3 col-12">
                                <p>اسم المنتج</p>
                            </div>
                            <div class="col-lg-2 col-md-2 col-12">
                                <p>السعر</p>
                            </div>
                            <div class="col-lg-2 col-md-2 col-12">
                                <p>الكميه</p>
                            </div>
                            <div class="col-lg-2 col-md-2 col-12">
                                <p>الاجمالي</p>
                            </div>
                            <div class="col-lg-1 col-md-2 col-12">
                                <p>حذف</p>
                            </div>
                        </div>
                    </div>
                    <!-- End Cart List Title -->
                    <?php $__currentLoopData = Cart::instance('cart')->content(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Cart Single List list -->
                        <div class="cart-single-list">
                            <div class="row align-items-center">
                                <div class="col-lg-1 col-md-1 col-12">
                                    <a href="<?php echo e(route('product', $item->id)); ?>"><img src="<?php echo e($item->model->main_image); ?>"
                                            alt="#" /></a>
                                </div>
                                <div class="col-lg-4 col-md-3 col-12">
                                    <h5 class="product-name">
                                        <a href="<?php echo e(route('product', $item->id)); ?>"><?php echo e($item->name); ?></a>
                                    </h5>
                                </div>
                                <div class="col-lg-2 col-md-2 col-12">
                                    <p><?php echo e($item->price); ?></p>
                                </div>
                                <div class="col-lg-2 col-md-2 col-12">
                                    
                                    <form action="<?php echo e(route('update_cart', $item->rowId)); ?>" method="post" id="form_update">
                                        <?php echo csrf_field(); ?>
                                        <input
                                            style="width: 60px;
                                        border: 1px solid #853b21;
                                        padding: 5px 10px 5px 2px;"
                                            class="count-input" type="number" name="qty" min="1" id=""
                                            value="<?php echo e($item->qty); ?>"
                                            onchange="document.getElementById('form_update').submit()">
                                    </form>
                                </div>
                                <div class="col-lg-2 col-md-2 col-12">
                                    <p><?php echo e($item->subtotal); ?></p>
                                </div>
                                <div class="col-lg-1 col-md-2 col-12">
                                    <a class="remove-item" href="<?php echo e(route('delete_cart', $item->id)); ?>"><i
                                            class="lni lni-close"></i></a>
                                </div>
                            </div>
                        </div>
                        <!-- End Single List list -->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="row">
                    <div class="col-12">
                        <!-- Total Amount -->
                        <div class="total-amount">
                            <div class="row">
                                <div class="col-lg-8 col-md-6 col-12">
                                    
                                </div>
                                <div class="col-lg-4 col-md-6 col-12">
                                    <div class="right">
                                        <ul>
                                            <li>المجموع <span><?php echo e(Cart::instance('cart')->total()); ?> ريال </span></li>
                                            <li>رسوم التوصيل <span>28 ريال</span></li>
                                            <li>ضريبه<span><?php echo e(Cart::instance('cart')->tax()); ?></span></li>
                                            <li class="last">
                                                المجموع الكلي<span><?php echo e(Cart::instance('cart')->total()+28); ?> ريال </span>
                                            </li>
                                        </ul>
                                        <div class="button">
                                            <a href="<?php echo e(route('checkout')); ?>" style="margin-right: 0"
                                                class="btn">الدفع</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--/ End Total Amount -->
                    </div>
                </div>
            </div>
        </div>
        <!--/ End Shopping Cart -->
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u572991200/domains/tmouralali.shop/public_html/resources/views/cart.blade.php ENDPATH**/ ?>