
<?php $__env->startSection('content'); ?>
    <!-- Start Breadcrumbs -->
    <div class="breadcrumbs">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 col-md-6 col-12">
                    <div class="breadcrumbs-content">
                        <h1 class="page-title">طلباتي</h1>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-12">
                    <ul class="breadcrumb-nav">
                        <li>
                            <a href="<?php echo e(route('home')); ?>"><i class="lni lni-home"></i> الرئيسيه</a>
                        </li>
                        <li><a href="<?php echo e(route('products')); ?>">المنتجات</a></li>
                        <li>طلباتي</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!-- End Breadcrumbs -->

    <!-- Shopping Cart -->

    <?php if(count($orders)): ?>
        <div class="shopping-cart section">
            <div class="container">
                <div class="cart-list-head">
                    <table class="table">
                        <thead class="thead-dark text-light bg-dark" style="background-color: #853b21 !important">
                            <tr>
                                <th scope="col">رقم الطلب</th>
                                <th scope="col">التاريخ</th>
                                <th scope="col">الحالة</th>
                                <th scope="col">التكلفة</th>
                                <th scope="col">المنتجات</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($order->id); ?></th>
                                    <td><?php echo e(date('d-m-Y', strtotime($order->created_at))); ?></td>
                                    <td> مكتمل</td>
                                    <td><?php echo e($order->total); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <p>
                                                <span><?php echo e($product->name); ?></span>
                                                <?php echo e($product->pivot->price); ?>

                                                <span>X</span>
                                                <?php echo e($product->pivot->qty); ?>

                                            </p>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!--/ End Shopping Cart -->
    <?php else: ?>
        <div class="shopping-cart section" style="    text-align: center;
font-size: 30px;">لايوجد طلبات لديك</div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u572991200/domains/tmouralali.shop/public_html/resources/views/orders.blade.php ENDPATH**/ ?>